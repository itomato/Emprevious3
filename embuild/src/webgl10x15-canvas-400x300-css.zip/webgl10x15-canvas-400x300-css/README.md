# WebGL - 10x15 canvas 400x300 css

A Pen created on CodePen.io. Original URL: [https://codepen.io/William-Kennedy-the-lessful/pen/jOXEYxV](https://codepen.io/William-Kennedy-the-lessful/pen/jOXEYxV).

from: https://webglfundamentals.org/webgl/webgl-10x15-canvas-400x300-css.html